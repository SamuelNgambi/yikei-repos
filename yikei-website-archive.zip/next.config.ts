import type { NextConfig } from "next";

const nextConfig: NextConfig = {
    // @ts-ignore
    devIndicators: false,
};

export default nextConfig;
